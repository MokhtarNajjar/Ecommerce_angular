export class Produit {
  id: string;
  titre: string;
  description: string;
  quantite: number;
  prix: number;
  photo: string;
  vendeur: string;
  id_vd: string;
  etat: string;
  dt: any;
}
