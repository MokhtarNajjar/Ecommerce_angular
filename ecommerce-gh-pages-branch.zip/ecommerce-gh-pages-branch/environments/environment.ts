// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
 apiKey: "AIzaSyB0hRkiH_3bBYuHZv9qyUbjkrIOnzzlsyg",
    authDomain: "webscrap-f81f0.firebaseapp.com",
    databaseURL: "https://webscrap-f81f0.firebaseio.com",
    projectId: "webscrap-f81f0",
    storageBucket: "webscrap-f81f0.appspot.com",
    messagingSenderId: "390571788861",
    appId: "1:390571788861:web:052f4eac4291986f57b854",
    measurementId: "G-7FNMWWZBE5",
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
